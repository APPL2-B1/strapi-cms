<div class="page">
    <h2><?php echo $lang_search_page_title; ?></h2>
    <input type="text"></input>
</div>