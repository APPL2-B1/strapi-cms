<div class="page">
    <h2><?php echo $lang_profile_page_title; ?></h2>
    <p><?php echo $lang_profile_page_description; ?></p>
    <a href="index.php?page=major_profile"><?php echo $lang_navigation_major_profile; ?></a></br>
    <a href="index.php?page=staff_profile_list"><?php echo $lang_navigation_staff_profile_list; ?></a></br>
    <a href="index.php?page=studi_programs_profile"><?php echo $lang_navigation_studi_programs_profile; ?></a>
</div>