<div class="page">
    <h1>ACHIEVEMENT LIST</h1>
    <a href="<?php echo ACHIVEMENT_PATH."1";?>">achievement 1</a>
    <a href="<?php echo ACHIVEMENT_PATH."2";?>">achievement 2</a>
    <a href="<?php echo ACHIVEMENT_PATH."3";?>">achievement 3</a>
</div>