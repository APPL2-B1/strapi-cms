<div class="page">
    <h2><?php echo $lang_curriculum_page_title; ?></h2>
    <p><?php echo $lang_curriculum_page_description; ?></p>
</div>