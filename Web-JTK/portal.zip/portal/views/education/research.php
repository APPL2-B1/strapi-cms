<div class="page">
    <h2><?php echo $lang_achievement_list_page_title; ?></h2>
    <p><?php echo $lang_achievement_list_page_description; ?></p>
</div>