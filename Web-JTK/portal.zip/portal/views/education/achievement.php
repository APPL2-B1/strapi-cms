<div class="page">
<?php 
$achievement_id = $_GET['id'];  
echo "<h1>".$achievement_id."</h1>";
?>
</div>