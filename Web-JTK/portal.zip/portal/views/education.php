<div class="page">
    <h2><?php echo $lang_education_page_title; ?></h2>
    <p><?php echo $lang_education_page_description; ?></p>
    
    <a href="<?php echo ACHIVEMENT_LIST_PATH;?>"><?php echo $lang_navigation_achievement_list; ?></a></br>
    <a href="index.php?page=curriculum"><?php echo $lang_navigation_curriculum; ?></a></br>
    <a href="index.php?page=agenda"><?php echo $lang_navigation_agenda; ?></a></br>
    <a href="index.php?page=achievement_list"><?php echo $lang_navigation_achievement_list; ?></a>
</div>