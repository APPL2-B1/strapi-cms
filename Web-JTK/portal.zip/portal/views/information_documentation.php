<div class="page">
    <h2><?php echo $lang_information_documentation_page_title; ?></h2>
    <p><?php echo $lang_information_documentation_page_description; ?></p>
    
    <a href="index.php?page=gallery"><?php echo $lang_navigation_gallery; ?></a></br>
    <a href="index.php?page=tracer_study"><?php echo $lang_navigation_tracer_study; ?></a>
</div>